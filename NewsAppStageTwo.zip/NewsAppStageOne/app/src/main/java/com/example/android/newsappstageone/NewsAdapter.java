package com.example.android.newsappstageone;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;

public class NewsAdapter extends RecyclerView.Adapter<NewsAdapter.MyViewHolder>{

    private Context context;
    private ArrayList<News> newsList;
    public NewsAdapter(Context context, ArrayList<News> newsList){
        this.newsList = newsList;
        this.context = context;
    }

    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext())
                .inflate(R.layout.news_item, viewGroup, false);
        MyViewHolder myViewHolder = new MyViewHolder(view);
        return myViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull NewsAdapter.MyViewHolder myViewHolder, int listPosition) {

        final News news = newsList.get(listPosition);

        TextView sectionView = myViewHolder.sectionView;
        TextView titleView = myViewHolder.titleView;
        TextView dateView = myViewHolder.dateView;
        TextView authorView = myViewHolder.authorView;

        sectionView.setText(newsList.get(listPosition).getNewsSection());
        titleView.setText(newsList.get(listPosition).getArticleTitle());
        dateView.setText(newsList.get(listPosition).getDatePublished());
        authorView.setText(newsList.get(listPosition).getAuthorName());

        titleView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(news.getUrl()));
                browserIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(browserIntent);
            }
        });


    }

    @Override
    public int getItemCount() {
        return newsList.size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder {

        TextView sectionView;
        TextView titleView;
        TextView dateView;
        TextView authorView;

        public MyViewHolder(View itemView) {
            super(itemView);
            this.titleView = itemView.findViewById(R.id.title_view);
            this.sectionView =  itemView.findViewById(R.id.section_view);
            this.dateView = itemView.findViewById(R.id.date_view);
            this.authorView = itemView.findViewById(R.id.author_name_view);
        }
    }
}
