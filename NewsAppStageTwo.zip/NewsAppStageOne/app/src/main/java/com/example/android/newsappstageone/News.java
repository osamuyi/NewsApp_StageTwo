package com.example.android.newsappstageone;

public class News {

    private String articleTitle;

    // Section that the article belongs to
    private String newsSection;

    private String authorName;

    private String datePublished;

    private String url;

    public News(String articleTitle, String newsSection, String authorName, String datePublished, String url) {
        this.articleTitle = articleTitle;
        this.newsSection = newsSection;
        this.authorName = authorName;
        this.datePublished = datePublished;
        this.url = url;
    }

    public String getArticleTitle() {
        return articleTitle;
    }

    public void setArticleTitle(String articleTitle) {
        this.articleTitle = articleTitle;
    }

    public String getNewsSection() {
        return newsSection;
    }

    public void setNewsSection(String newsSection) {
        this.newsSection = newsSection;
    }

    public String getAuthorName() {
        return authorName;
    }

    public void setAuthorName(String authorName) {
        this.authorName = authorName;
    }

    public String getDatePublished() {
        return datePublished;
    }

    public void setDatePublished(String datePublished) {
        this.datePublished = datePublished;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
}
